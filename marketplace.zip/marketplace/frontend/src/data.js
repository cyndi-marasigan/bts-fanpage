import bcrypt from 'bcryptjs';

const data= {
    users: [
        {
          name: 'mabuX',
          email: 'admin@example.com',
          password: bcrypt.hashSync('1234', 8),
          isAdmin: true,
        },
        { 
          name: 'John',
          email: 'user@example.com',
          password: bcrypt.hashSync('1234', 8),
          isAdmin: false,
        },
      ],
    products:[
        {  
            name: "Jin Spicy/Mild Flavor",
            category: 'noodle',
            image: '/images/jin.jpg',
            price: 35,
            countInStock: 50,
            brand: 'Ottogi',
            rating: 4.5,
            numReview: 10,
            description: 'Ottogi Jin Ramen Spicy and Mild'
        },
        {
            
            name: "Beef Bulgogi Noodle",
            category: 'noodle',
            image: '/images/bulgogi.jpg',
            price: 25,
            countInStock: 22,
            brand: 'Nongshim',
            rating: 5,
            numReview: 13,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Ramyun Noodle Soup",
            category: 'noodle',
            image: '/images/nongshim.jpg',
            price: 30,
            countInStock: 26,
            brand: 'Nongshim',
            rating: 2.5,
            numReview: 13,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Chapaghetti Ramen",
            category: 'noodle',
            image: '/images/chapaghetti.jpg',
            price: 50,
            countInStock:3,
            brand: 'Nongshim',
            rating: 3,
            numReview: 6,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Neoguri Seafood Spicy",
            category: 'noodle',
            image: '/images/neoguri.jpg',
            price: 35,
            countInStock:11,
            brand: 'Nongshim',
            rating: 5,
            numReview: 25,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Sunhari Soju",
            category: 'soju',
            image: '/images/soju.jpg',
            price: 129,
            countInStock:0,
            brand: 'Lotte',
            rating: 5,
            numReview: 55,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Binggrae Flavored Milk",
            category: 'milk',
            image: '/images/flavoredmilk.jpg',
            price: 10,
            countInStock:80,
            brand: 'Binggrae',
            rating: 5,
            numReview: 120,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Melona Waffle Red Bean Flavor",
            category: 'Ice cream',
            image: '/images/samanco.jpg',
            price: 5,
            countInStock: 98,
            brand: 'Samanco',
            rating: 5,
            numReview: 98,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Raspberry Custard Mochi",
            category: 'mochi',
            image: '/images/mochi.jpg',
            price: 35,
            countInStock: 29,
            brand: 'Royal Family',
            rating: 5,
            numReview: 96,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
        {
            
            name: "Topokki Rice Cake",
            category: 'rice cake',
            image: '/images/yopokki.jpg',
            price: 3,
            countInStock: 36,
            brand: 'Yopokki',
            rating: 5,
            numReview: 29,
            description: 'Comes with a dehydrated vegetable mix consisting of Chinese cabbage, mushroom, carrot, green onion, red pepper, and textured vegetable protein.'
        },
    ]
}
export default data;